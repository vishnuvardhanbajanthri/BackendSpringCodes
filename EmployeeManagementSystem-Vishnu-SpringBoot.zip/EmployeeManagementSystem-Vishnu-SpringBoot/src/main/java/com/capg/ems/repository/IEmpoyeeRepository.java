package com.capg.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.ems.entities.Employee;

public interface IEmpoyeeRepository extends JpaRepository<Employee,Integer> {

}
