package com.capg.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.ems.entities.Compliance;

public interface IComplianceRepository extends JpaRepository<Compliance, Integer> {

}
