package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Department;

public interface IDepartmentService {
	public void addDepartment(String dname);
	public List<Department> getAllDepartments();
	public List<Department> getAllDepartByPagination(String maxPage,String ofset);
	public int getAllDepartCount();
	public boolean deleteDepartment(int id);
}
