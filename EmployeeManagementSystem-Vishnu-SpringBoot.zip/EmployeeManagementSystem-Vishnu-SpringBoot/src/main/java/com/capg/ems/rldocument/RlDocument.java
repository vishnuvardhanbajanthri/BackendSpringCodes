package com.capg.ems.rldocument;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class RlDocument {
	public static void main(String[] args) {

		try {
			File file = new File("RLDoc.txt");
			if (!file.exists()) {
				file.createNewFile();
			}
			PrintWriter printWriter = new PrintWriter(file);
//			printWriter.println("Hello");
//			printWriter.println(10000);
			printWriter.close();
			System.out.println("your Regulation created ");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
