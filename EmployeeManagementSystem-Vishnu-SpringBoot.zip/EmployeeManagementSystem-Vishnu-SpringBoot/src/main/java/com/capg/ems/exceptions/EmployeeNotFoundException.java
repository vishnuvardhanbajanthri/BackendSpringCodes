package com.capg.ems.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException( String message){
        super(message);
    }
}
