package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Department;

public class IDepartmentServiceImpl implements IDepartmentService {

	@Override
	public void addDepartment(String dname) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Department> getAllDepartByPagination(String maxPage, String ofset) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getAllDepartCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deleteDepartment(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
