package com.capg.ems.service;

import java.util.List;
import java.util.Optional;
import org.springframework.aop.ThrowsAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import com.capg.ems.entities.Employee;
import com.capg.ems.exceptions.EmployeeNotFoundException;
import com.capg.ems.repository.IEmpoyeeRepository;

public class IEmployeeServiceImpl implements IEmployeeService{
	@Autowired
	IEmpoyeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee emp) {
		Employee employee=employeeRepository.save(emp);
		return employee;
	}

	@Override
	public String deleteEmployee(int id) throws EmployeeNotFoundException  {
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeNotFoundException("Oops!! No Employee Found With this Id");
		}else {
			employeeRepository.deleteById(id);
			return "Employee Deleted Successfully";
		}
		
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeNotFoundException {
		if(!employeeRepository.existsById(emp.getUserid())) {
			throw new EmployeeNotFoundException("Oops!! No Employee Found With this Id");
		}else {
			employeeRepository.save(emp);
		}
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> list=employeeRepository.findAll();
		return list;
	}

	@Override
	public Employee getEmployeeById(int userid) {
		Optional<Employee> optional = employeeRepository.findById(userid);
		Employee employee = null;
		if (optional.isPresent()) {
			employee = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for id :: " + userid);
		}
		return employee;
		
	}

	@Override
	public List<Employee> getAllEmployeesByPagination(String maxPage, String ofset) {
		return null;
	}

	@Override
	public int getEmployeeCount() {
		
		return 0;
	}

}
