package com.capg.ems.service;

import com.capg.ems.entities.User;

public class ILoginServiceImpl implements ILoginService {

	@Override
	public User validateUser(User user) {
		
		return null;
	}

}
