package com.capg.ems.service;

import com.capg.ems.entities.User;

public interface ILoginService {
	public User validateUser(User user);
	
}
