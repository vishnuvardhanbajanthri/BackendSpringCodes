package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Employee;
import com.capg.ems.exceptions.EmployeeNotFoundException;


public interface IEmployeeService {
	
	public Employee addEmployee(Employee emp);
	public String deleteEmployee(int id) throws EmployeeNotFoundException;
	public Employee updateEmployee(Employee emp) throws EmployeeNotFoundException;
	public List<Employee> getAllEmployees();
	public Employee getEmployeeById(int userid);
	public List<Employee> getAllEmployeesByPagination(String maxPage,String ofset);
	public int getEmployeeCount();
	
}
