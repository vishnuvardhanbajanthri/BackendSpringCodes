package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Compliance;
import com.capg.ems.entities.StatusReport;

public class IComplianceServiceImpl implements IComplianceService {

	@Override
	public void createRL(Compliance co) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Compliance> getAllRL() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Compliance> getAllRL(String UserId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createStatusReport(StatusReport statusreport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<StatusReport> getAllStatusReport(String userId, int compid) {
		// TODO Auto-generated method stub
		return null;
	}

}
