package com.capg.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.ems.entities.Department;

public interface IDepartmentRepository extends JpaRepository<Department, Integer>{

}
