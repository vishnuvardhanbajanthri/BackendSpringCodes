package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Employee;


public interface IEmployeeService {
	
	public Employee addEmployee(Employee emp);
	public void deleteEmployee(int id);
	public Employee updateEmployee(Employee emp);
	public List<Employee> getAllEmployees();
	public Employee getEmployeeById(int userid);
	public List<Employee> getAllEmployeesByPagination(String maxPage,String ofset);
	public int getEmployeeCount();
	
}
