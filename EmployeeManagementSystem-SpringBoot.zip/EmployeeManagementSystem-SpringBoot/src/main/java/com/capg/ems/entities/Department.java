package com.capg.ems.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="department")
public class Department {
	@Id
	@Column(name="department_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int departid;
	private String departName;
	
	public Department() {
		
	}
	
	public Department(int departid){
		super();
		this.departid = departid;
	}
	
	public Department(int departid, String departName) {
		super();
		this.departid = departid;
		this.departName = departName;
	}
	
	public int getDepartid() {
		return departid;
	}
	public void setDepartid(int departid) {
		this.departid = departid;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	
	@Override
	public String toString() {
		return "Department [departid=" + departid + ", departName=" + departName + "]";
	}

}
