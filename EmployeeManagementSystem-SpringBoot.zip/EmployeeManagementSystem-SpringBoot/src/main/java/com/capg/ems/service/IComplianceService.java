package com.capg.ems.service;

import java.util.List;

import com.capg.ems.entities.Compliance;
import com.capg.ems.entities.StatusReport;


public interface IComplianceService {
	public void createRL(Compliance co);
	public List<Compliance> getAllRL();
	public List<Compliance> getAllRL(String UserId);
	public void createStatusReport(StatusReport statusreport);
	public List<StatusReport> getAllStatusReport(String userId,int compid);
}
