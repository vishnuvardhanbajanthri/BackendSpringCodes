package com.capg.ems.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/*
 * StatusReportRepository Interface for EmployeeManagementSystem
 * Author : Vishnuvardhan
 * Date Created :07/01/2021
 */
import com.capg.ems.entities.StatusReport;
@Repository
public interface StatusReportRepository extends CrudRepository<StatusReport, Integer> {
	
}