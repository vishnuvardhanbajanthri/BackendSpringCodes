package com.capg.ems.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.ems.entities.Employee;

/*EmployeeRepository for Employee Management System
 * Author: Riyanka Ghosh
 * Date Created: 06/01/2022
 */

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.ems.entities.Employee;

@Repository
public interface IEmployeeRepository extends CrudRepository<Employee, Integer> {
}
