package com.capg.ems.service;

import java.util.List;

import com.capg.ems.dto.EmployeeDTO;
import com.capg.ems.entities.Employee;
import com.capg.ems.exceptions.*;

/*Service Interface for Employee Management System
 * Author: Riyanka Ghosh
 * Date Created: 09/01/2022
 */

public interface IEmployeeService {

	public List<Employee> getAllEmployees();

	public EmployeeDTO addEmployee(String emp);

	public void deleteEmployee(int userId) throws EmployeeNotFoundException;

	public EmployeeDTO updateEmployee(String emp);

	public EmployeeDTO getEmployeeById(int userid) throws EmployeeNotFoundException;

	public List<Employee> getAllEmployeesByPagination(String maxPage, String ofset);

	public long getEmployeeCount();

}
