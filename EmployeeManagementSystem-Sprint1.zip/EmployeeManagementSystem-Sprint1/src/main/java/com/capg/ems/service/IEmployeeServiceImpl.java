package com.capg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.ems.dto.EmployeeDTO;
import com.capg.ems.entities.Employee;
import com.capg.ems.repository.IEmployeeRepository;
import com.capg.ems.exceptions.EmployeeNotFoundException;

@Service
public class IEmployeeServiceImpl {

	@Autowired
	public IEmployeeRepository empRepo;

	/************************************************************************************
	 * Method: addEmployee Description: It is used to add Employee into Employee
	 * table
	 * 
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public EmployeeDTO addEmployee(EmployeeDTO emp) {
		Employee ent = convertToEntity(emp);
		Employee updatedEnt = empRepo.save(ent);
		return convertToDTO(updatedEnt);
	}

	/************************************************************************************
	 * Method: deleteEmployee Description: It is used to delete Employee from the
	 * Employee table
	 * 
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public void deleteEmployee(int userId) {
		empRepo.deleteById(userId);
	}

	/************************************************************************************
	 * Method: updateEmployee Description: It is used to update employee into
	 * Employee table
	 * 
	 * @returns EmployeeDTO It returns Employee with updated details
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public EmployeeDTO updateEmployee(EmployeeDTO emp) {
		Employee ent = convertToEntity(emp);
		Employee updatedEnt = empRepo.save(ent);
		return convertToDTO(updatedEnt);
	}

	/************************************************************************************
	 * Method: getAllEmployees Description: It is used to view all Employees in
	 * employee table
	 * 
	 * @returns List<EmployeeDTO> It returns all the employees with details
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public List<EmployeeDTO> getAllEmployees() {
		Iterable<Employee> emps = empRepo.findAll();
		List<EmployeeDTO> dtoList = new ArrayList<>();
		for (Employee employee : emps) {
			EmployeeDTO dto = convertToDTO(employee);
			dtoList.add(dto);
		}
		return dtoList;
	}

	/************************************************************************************
	 * Method: getEmployeeById Description: It is used to get employee in Employee
	 * table by userId
	 * 
	 * @throws EmployeeNotFoundException
	 * 
	 * @returns <Employee> It returns Employee with details
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public Optional<Employee> getEmployeeById(int userId) throws EmployeeNotFoundException {
		if (!empRepo.existsById(userId)) {
			throw new EmployeeNotFoundException("Oops!!No User found for given Id");
		} else {
			return empRepo.findById(userId);

		}
	}

	/************************************************************************************
	 * Method: getEmployeeCount Description: It is used to get the count of all
	 * employees in the employee table
	 * 
	 * @returns long It returns the count of employees
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * 
	 ************************************************************************************/

	public long getEmployeeCount() {
		return empRepo.count();
	}

	EmployeeDTO convertToDTO(Employee emp) {
		EmployeeDTO dto = new EmployeeDTO();
		dto.setFirstname(emp.getFirstName());
		dto.setLastname(emp.getLastname());
		dto.setDob(emp.getDob());
		dto.setEmail(emp.getEmail());
		dto.setUserId(emp.getUserId());
		dto.setDepartment(emp.getDepartment());
		return dto;
	}

	Employee convertToEntity(EmployeeDTO dto) {
		Employee entity = new Employee();
		entity.setFirstName(dto.getFirstname());
		entity.setLastname(dto.getLastname());
		entity.setDob(dto.getDob());
		entity.setEmail(dto.getEmail());
		entity.setUserId(dto.getUserId());
		entity.setDepartment(dto.getDepartment());
		return entity;

	}
}
