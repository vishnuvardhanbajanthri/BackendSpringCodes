package com.capg.ems.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.ems.entities.Department;
import com.capg.ems.exceptions.DepartmentNotFoundException;
import com.capg.ems.repository.IDepartmentRepository;

/*ServiceImplementation class for Employee Management System
Author : NIKHIL KUMAR
Date Created : 9/01/2022
*/
@Service
public class IDepartmentServiceImpl implements IDepartmentService{

	@Autowired
	IDepartmentRepository departRepo;

	/************************************************************************************
	 * Method: getAllDepartments
	 *  Description: It is used to get All department data
	 *               from Department table
	 ************************************************************************************/
	@Override
	public List<Department> getAllDepartments() {
		List<Department> depts = (List<Department>) departRepo.findAll();
		return depts;
	}

	/************************************************************************************
	 * Method: getDepartmentById 
	 * Description: It is used to get All department data
	 *              By Id from Department table
	 ************************************************************************************/
	@Override
	public Optional<Department> getDepartmentById(int id) throws DepartmentNotFoundException {
		if(!departRepo.existsById(id))
			throw new DepartmentNotFoundException("Department not found");
		else {
		return departRepo.findById(id);
	}
	}

	/************************************************************************************
	 * Method: addDepartment 
	 * Description: It is used to add Department into
	 *              Department table
	 ************************************************************************************/
	@Override
	public void addDepartment(Department departName) {
		departRepo.save(departName);
		
	}

	/************************************************************************************
	 * Method: deleteDepartmentById 
	 * Description: It is used to delete Department from
	 *              the Department table of respective id
	 *************************************************************************************/
	@Override
	public void deleteDepartmentById(int id) {
		departRepo.deleteById(id);
		
	}

	/************************************************************************************
	 * Method: counts 
	 * Description: It is used to get count of Records from department table
	 ************************************************************************************/
	@Override
	public long counts() {
		return departRepo.count();
	}
	
}
