package com.capg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.ems.entities.StatusReport;
import com.capg.ems.exceptions.StatusReportNotFoundException;
import com.capg.ems.repository.StatusReportRepository;

/*
 * StatusReportSeviceimpl Class for EmployeeManagementSystem
 * Author : Vishnuvardhan
 * Date Created :09/01/2021
 */



@Service
public class StatusReportSeviceimpl implements StatusReportService {
	@Autowired
	StatusReportRepository statusdao;
	
	public void addStatusReport(StatusReport statusrepo) throws StatusReportNotFoundException {
		statusdao.save(statusrepo);
	}

	@Override
	public List<StatusReport> getAllStatusReports(int userId, int compid) throws StatusReportNotFoundException {
		List<StatusReport> list=(List<StatusReport>)statusdao.findAll();
		return list;
	}

	@Override
	public long counts() {
		return statusdao.count();
	}

	@Override
	public void deleteStatusReport(int statusId) throws StatusReportNotFoundException {
		statusdao.deleteById(statusId);
	}

	@Override
	public StatusReport updateStatusReport(StatusReport statusReport) throws StatusReportNotFoundException {
		if(!statusdao.existsById(statusReport.getStatusId()))
			throw new StatusReportNotFoundException("Status Not Found");
		statusdao.save(statusReport);
		return statusReport;
	}
	

}
