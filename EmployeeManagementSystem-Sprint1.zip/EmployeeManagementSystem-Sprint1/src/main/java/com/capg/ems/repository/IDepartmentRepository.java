package com.capg.ems.repository;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.ems.entities.Department;
/*Repository Interface for Employee Management System
Author : NIKHIL KUMAR
Date Created : 8/01/2022
*/
@Repository
public interface IDepartmentRepository extends CrudRepository<Department, Integer> {

}
