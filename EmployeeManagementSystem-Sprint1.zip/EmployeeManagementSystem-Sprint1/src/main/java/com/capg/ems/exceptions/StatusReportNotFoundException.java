package com.capg.ems.exceptions;

public class StatusReportNotFoundException extends Exception {
	public StatusReportNotFoundException(String message) {
		super(message);
	}

	public StatusReportNotFoundException(String message, Throwable e) {
		super(e);
	}

}
