package com.capg.ems.service;

import java.util.List;
import com.capg.ems.entities.StatusReport;
import com.capg.ems.exceptions.StatusReportNotFoundException;
/*
 * StatusReportService Interface for EmployeeManagementSystem
 * Author : Vishnuvardhan
 * Date Created :07/01/2021
 */
public interface StatusReportService {
	public void addStatusReport(StatusReport statusrepo) throws StatusReportNotFoundException;
	public List<StatusReport> getAllStatusReports(int userId,int compid) throws StatusReportNotFoundException;
	public long counts();
	public void deleteStatusReport(int statusId) throws StatusReportNotFoundException;
	public StatusReport updateStatusReport(StatusReport statusReport) throws StatusReportNotFoundException;
}
