package com.capg.ems.exceptions;

/*UserDefException Class for Employee Management System
Author : NIKHIL KUMAR
Date Created : 9/01/2022
*/
public class DepartmentNotFoundException extends RuntimeException {

	/*
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DepartmentNotFoundException(String dep) {
		super(dep);
	}

    public DepartmentNotFoundException(String dep,Throwable e){
        super(dep,e);
    }
}
