package com.capg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capg.ems.entities.StatusReport;
import com.capg.ems.exceptions.EmployeeNotFoundException;
import com.capg.ems.exceptions.StatusReportNotFoundException;

/*
 * StatusReportController Class for EmployeeManagementSystem
 * Author : Vishnuvardhan
 * Date Created :10/01/2021
 */
import com.capg.ems.service.StatusReportSeviceimpl;

@RestController
@RequestMapping(value = "StatusReport")
@CrossOrigin("http://localhost:4200")
public class StatusReportController {
	@Autowired
	private StatusReportSeviceimpl service;
	
	/************************************************************************************
	 * Method: addStatusEntity Description: Adding StatusReport into Statusreport table
	 * 
	 * 
	 * @returns quote: It returns quote with details
	 * @PostMapping: It is used to handle the HTTP POST requests matched with given
	 *               URI expression.
	 * @RequestBody: It used to bind the HTTP request/response body with a domain
	 *               object in method parameter or return type.
	 ************************************************************************************/
	@PostMapping(path = "/add")
	public ResponseEntity<Boolean> addStatusEntity(@RequestBody StatusReport statusreport)
			throws StatusReportNotFoundException {
		service.addStatusReport(statusreport);
		ResponseEntity<Boolean> responseEntity = new ResponseEntity<Boolean>(true, null);
		System.out.println("Responce Entity=" + responseEntity);
		return responseEntity;
	}

	/************************************************************************************
	 * Method: getAllStatusReport Description: To get all the Statusreports from StatusReport table
	 * @throws StatusReportNotFoundException 
	 * @returns List<quote>: It returns List of quote with details
	 * @GetMapping: annotated methods handle the HTTP GET requests matched with
	 *              given URI expression
	 ************************************************************************************/
	
	@GetMapping(value = "/getAll")
	public ResponseEntity<List<StatusReport>> getAllStatusReport() throws StatusReportNotFoundException {
		List<StatusReport> list = service.getAllStatusReports(0, 0);
		return new ResponseEntity<List<StatusReport>>(list, new HttpHeaders(), HttpStatus.OK);
	}


	/************************************************************************************
	 * Method: counts Description: Getting Count of the Records
	 * the Employee table
	 * @returns List<Employee>: It returns List of quote with details
	 * @GetMapping: annotated methods handle the HTTP GET requests matched with
	 *              given URI expression
	 * 
	 ************************************************************************************/
	
	@GetMapping(value = "/count")
	public long counts() {
		return service.counts();
	}


	/************************************************************************************
	 * Method: updateStatusReport Description: Update Status Counting in the StatusReport
	 * table
	 * @throws StatusReportNotFoundException
	 * @returns quote: It returns quote with details
	 * @PostMapping: It is used to handle the HTTP POST requests matched with given
	 *               URI expression.
	 * @RequestBody: It used to bind the HTTP request/response body with a domain
	 *               object in method parameter or return type.
	 ************************************************************************************/
	
	@PostMapping("/updatestatus")
	public String updateStatusReport(@RequestBody StatusReport statusReport) throws StatusReportNotFoundException {
		service.updateStatusReport(statusReport);
		return "Status Updated Successfully";
	}
}
