package com.capg.ems.exceptions;

public class UserNotFoundException extends Exception {
	public UserNotFoundException(String s) {
		super(s);
	}
}