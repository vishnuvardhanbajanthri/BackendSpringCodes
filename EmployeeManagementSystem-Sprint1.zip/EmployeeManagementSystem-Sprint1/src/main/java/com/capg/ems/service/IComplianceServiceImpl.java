package com.capg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.ems.dto.ComplianceDTO;
import com.capg.ems.entities.Compliance;
import com.capg.ems.exceptions.ComplianceNotFoundException;
import com.capg.ems.repository.IComplianceRepository;

/*
 * Author : TANNU KUMARI
 * Date : 09-01-2022
 * Description : Compliance service layer Implementation
*/

@Service
public class IComplianceServiceImpl implements IComplianceService {

	@Autowired
	IComplianceRepository icomplianceRepository; // repository object (Autowired)

	/************************************************************************************
	 * Method: addCompliance 
	 * Description: It is used to add compliance into Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public ComplianceDTO addCompliance(ComplianceDTO com){
		Compliance c = convertToEntity(com);
		Compliance compliance = icomplianceRepository.save(c);
		return convertToDTO(compliance);

	}

	/************************************************************************************
	 * Method: getAllCompliances 
	 * Description: It is used to get all information of compliance from Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public List<ComplianceDTO> getAllCompliances() {
		Iterable<Compliance> comps = icomplianceRepository.findAll();
		List<ComplianceDTO> dtoList = new ArrayList<>();
		for (Compliance compliance : comps) {
			ComplianceDTO dto = convertToDTO(compliance);
			dtoList.add(dto);
		}
		return dtoList;
	}

	/************************************************************************************
	 * Method: getAllComplianceById 
	 * Description: It is used to get information of compliance from Compliance table by ID
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public Optional<Compliance> getComplianceById(int complianceId)  {

		if (!icomplianceRepository.existsById(complianceId)) {
			throw new ComplianceNotFoundException("Oops!!No User found for given Id");
		} else {
			return icomplianceRepository.findById(complianceId);
		}
	}

	/************************************************************************************
	 * Method: updateCompliance
	 * Description: It is used to update compliance into Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public ComplianceDTO updateCompliance(ComplianceDTO compliance) {
		Compliance com = convertToEntity(compliance);
		Compliance updatedEnt = icomplianceRepository.save(com);
		return convertToDTO(updatedEnt);
	}
	
	/************************************************************************************
	 * Method: convertToDTO
	 * Description: It is used to convert user defined data to DTO layer into Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	ComplianceDTO convertToDTO(Compliance com) {
		ComplianceDTO dto = new ComplianceDTO();
		dto.setItype(com.getItype());
		dto.setDetails(com.getDetails());
		dto.setCreatedate(com.getCreatedate());
		dto.setStatus(com.getStatus());
		dto.setComplianceId(com.getComplianceId());
		return dto;
	}
	
	/************************************************************************************
	 * Method: convertToDTO
	 * Description: It is used to convert user defined data to Entity layer into Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/

	Compliance convertToEntity(ComplianceDTO dto) {
		Compliance entity = new Compliance();
		entity.setItype(dto.getItype());
		entity.setDetails(dto.getDetails());
		entity.setCreatedate(dto.getCreatedate());
		entity.setStatus(dto.getStatus());
		entity.setComplianceId(dto.getComplianceId());
		return entity;

	}

	/************************************************************************************
	 * Method: getAllComplianceById 
	 * Description: It is used to get information of compliance from Compliance table
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public List<ComplianceDTO> getAllCompliance(int userId) throws ComplianceNotFoundException {

		if(!icomplianceRepository.existsById(userId))
    		throw new ComplianceNotFoundException("Regulation not found");
    	Optional<Compliance> regulation=icomplianceRepository.findById(userId);
		return icomplianceRepository.findAllById(regulation);
	
	}
	
	/************************************************************************************
	 * Method: deleteCompliance 
	 * Description: It is used to delete the information of compliance from Compliance table by ID
	 * @Override: It is used to override the JpaRepository methods for performing CURD operations.
	 * Created By- TANNU KUMARI
	 * Created Date - 09-01-2022
	 ************************************************************************************/
	
	@Override
	public void deleteCompliance(int complianceId) {
		
		icomplianceRepository.deleteCompliance(complianceId);
	}

}

