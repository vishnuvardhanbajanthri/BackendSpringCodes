package com.capg.ems.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.ems.dto.ComplianceDTO;
import com.capg.ems.entities.Compliance;

/*
 * Author : TANNU KUMARI
 * Date : 07-01-2022
 * Description : Compliance repository
*/

@Repository
public interface IComplianceRepository extends CrudRepository<Compliance, Integer> {

	List<ComplianceDTO> findAllById(Optional<Compliance> regulation);

	void deleteCompliance(int complianceId);


}

