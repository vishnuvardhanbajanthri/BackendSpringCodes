package com.capg.ems.statusmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemStatusModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
